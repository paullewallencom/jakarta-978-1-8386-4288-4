package com.eldermoraes.ch03.sse;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author eldermoraes
 */
@ApplicationPath("webresources")
public class ApplicationConfig extends Application {

}
