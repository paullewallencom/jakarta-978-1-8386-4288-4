package com.eldermoraes.ch05.declarative;

/**
 *
 * @author eldermoraes
 */
public class Roles {
    public static final String ADMIN = "admin";
    public static final String USER = "user";
}
    
