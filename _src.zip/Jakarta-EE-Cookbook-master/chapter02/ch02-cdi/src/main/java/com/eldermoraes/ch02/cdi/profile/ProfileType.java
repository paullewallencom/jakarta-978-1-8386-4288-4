package com.eldermoraes.ch02.cdi.profile;

/**
 *
 * @author eldermoraes
 */
public enum ProfileType {
    ADMIN, OPERATOR;
}
