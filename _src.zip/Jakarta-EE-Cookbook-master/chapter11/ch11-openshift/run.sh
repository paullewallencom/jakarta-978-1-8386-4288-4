docker run -d --name gf-jakartaee-cookbook-os \
    -h gf-javaee-cookbook-os \
    -p 80:8080 \
    -p 4848:4848 \
    -p 8686:8686 \
    -p 8009:8009 \
    -p 8181:8181 \
    eldermoraes/gf-jakartaee-cookbook-os