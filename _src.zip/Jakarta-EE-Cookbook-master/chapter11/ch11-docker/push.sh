  docker login
  docker push eldermoraes/gf-jakartaee-cookbook