docker login
docker push eldermoraes/gf-jakartaee-jdk8
