docker build -t eldermoraes/gf-jakartaee-jdk8 .
